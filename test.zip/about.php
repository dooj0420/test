<?php include('include/header.php'); ?>

  <div class="main-content">
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-stellar-background-ratio="0.5" data-bg-img="images/bg/bg1.jpg">
      <div class="container pt-100 pb-50">
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-12">
              <h3 class="title text-white">About</h3>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="section-content">
          <div class="row">
            <div class="col-md-8">
              <h3 class="text-uppercase font-28 letter-space-3">We are <span class="text-theme-colored">Ready</span> We make excellent<br> work and give best advice.</h3>
                <p>Why would I not ponder when it’s my own income? Is it equitable to earn as well as to manage it? It’s our responsibility to respect your anxiety&nbsp; and transform all of your reveries into a truth. Our piece of cake is to serve you with the best wealth management plans.As your income is our heritage. “Not he who earns much is rich, but he who knows how to manage”. Our commitment is to take care of your financial assets.We are committed to takeover your worries&nbsp;and provide you with the plan that&nbsp;fulfill all your dreams</p>
            </div>
            <div class="col-md-4">
              <div class="thumb">
                <img alt="" src="images/about/w1.jpg" class="img-fullwidth">
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="divider parallax layer-overlay overlay-deep" data-bg-img="images/bg/bg2.jpg" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row text-justify">
          <div class="col-md-6">
            <h4>Vision</h4>
            <p>A true friend that paves a road to your beautiful future. BONAZ CAPITAL Investment Advisor solutions partner, a stock advisory in Indore provides you with the best of these services-Stock tips,Share Market tips,MCX tips,Nifty Futures,NCDEX tips,Forex tips,NSE BSE Stock Market tips,Equity tips,HNI Commodity pack etc.We are a hand starving to hold another needy hand to snatch all the wealth related troubles.</p>
          </div>
          <div class="col-md-6">
            <h4>Mission</h4>
            <p>We care for your secure future as your needs are our responsibilities. Our clients are assets to us; we would love to flourish them by providing with justifiable plans. Reliability, authenticity, Confidentiality of our client are our sincere concerns.</p>
          </div>
        </div>
      </div>
    </section>
    


<?php include('include/footer.php'); ?>